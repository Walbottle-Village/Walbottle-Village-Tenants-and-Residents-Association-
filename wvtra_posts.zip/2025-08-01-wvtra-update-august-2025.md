---
layout: post
title: "WVTRA Update – August 2025"
date: 2025-08-01
categories: updates
tags: [wvtra, meetings, events]
---

We're still here! It's been a busy time for our small team of volunteers...

- Weds 6 Aug – Open Meeting at The Engine Inn (6:30–8pm)  
  All welcome from 6pm – the pub quiz starts at 8pm for those who want to stay!
- Weds 1 Oct – AGM at Walbottle Village Institute (7–9pm)  
  All welcome for refreshments from 6:30pm. Yearly gathering for all to summarise the past year and make important and positive decisions on WVTRA's future.
- Sun 5 Oct – Foodbank Collection  
  Walbottle Village Institute, 10am–12 noon
- Fri 31 Oct – Halloween Trail  
  4–7pm
- Weds 3 Dec – Open Meeting at Walbottle Village Institute (7–9pm)  
  All welcome for refreshments from 6:30pm. Informal meeting to update on village news/activity/events & share ideas.
- Sun 7 Dec – Christmas at Walbottle Village Institute (4–7pm)  
  Christmas celebrations and festive cheer for all at WVI & on The Green – refreshments, arts & crafts, stalls, choir and more.

You can keep up to date on [www.walbottlevillagetra.co.uk](http://www.walbottlevillagetra.co.uk).
