---
layout: post
title: "Food Bank Collection"
date: 2023-10-08
categories: events
tags: [foodbank, community-support]
---

Sunday 15 October, 10:30–11:30 in the Village Institute.
