---
layout: post
title: "Litter in Post Box"
date: 2024-06-13
categories: announcements
tags: [community-issues, post-office]
---

The village postman mentioned problems with people putting rubbish and grass cuttings in the post box by Head to Toe.  
If this continues, the post box may be taken out of service.  
Please keep an eye out and discourage this behaviour.
