---
layout: post
title: "Walbottle Choir"
date: 2023-10-06
categories: activities
tags: [choir, community-groups, weekly-events]
---

Meeting every Monday (excluding bank holidays) in the Village Institute at 7:30pm for one hour. £2 per session.
