---
layout: post
title: "Residents Meeting"
date: 2024-01-19
categories: meetings
tags: [meetings, wvtra]
---

Tuesday 23 Jan, 19:30 in the Village Institute.  
View the agenda.
