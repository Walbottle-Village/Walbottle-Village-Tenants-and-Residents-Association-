---
layout: post
title: "Expressions Of Interest Welcome"
date: 2024-12-16
categories: announcements
tags: [trustees, village-institute, volunteers]
---

The Trustees of Walbottle Village Institute invite expressions of interest from Walbottle Residents to become additional Trustees of the Walbottle Village Institute Charity.

Trustees are volunteers who lead charities and decide how they are run. They have independent control and legal responsibility for the charity's management.

**Eligibility:**
- 18 years or older
- Not disqualified by the Charities Commission

**Learn more:** [Charity trustee: what's involved](https://www.gov.uk/government/publications/charity-trustee-whats-involved)  
**Contact:** wendy@walbottlevi.com
