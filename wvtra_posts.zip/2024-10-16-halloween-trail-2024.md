---
layout: post
title: "Halloween Trail 2024"
date: 2024-10-16
categories: events
tags: [halloween, community-events]
---

Our popular Halloween trail will take place on Thursday 31 October, starting from Walbottle Coffee House, turn up between 4pm and 7pm.
