---
layout: post
title: "Food Bank Collection"
date: 2024-12-02
categories: events
tags: [foodbank, community-support]
---

Sunday 5 January 2025, 10am to 12:00 in the Village Institute.
