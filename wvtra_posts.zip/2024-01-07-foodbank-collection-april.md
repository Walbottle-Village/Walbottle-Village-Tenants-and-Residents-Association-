---
layout: post
title: "Food Bank Collection"
date: 2024-01-07
categories: events
tags: [foodbank, community-support]
---

Sunday 7 April, 10:30–12:00 in the Village Institute.
