---
layout: post
title: "Food Bank Collection Update"
date: 2024-01-05
categories: updates
tags: [foodbank, community-support, thank-you]
---

Sunday 7 January, 10:30–12:00 in the Village Institute.  

Food donated: 30 pasta, 12 rice, 10 pot noodles, 8 noodles, 8 spaghetti, 9 meat tins, 20 tuna, 27 beans, 29 sauces, 12 cereals, 19 soup, and more.  

Thank you!
