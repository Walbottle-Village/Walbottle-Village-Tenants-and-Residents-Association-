---
layout: post
title: "D-DAY Anniversary Commemorative & Celebration Events"
date: 2024-05-09
categories: announcements
tags: [events, cancellation]
---

It is with regret that, due to unforeseen circumstances, the Walbottle Village D Day Committee has had to cancel both the Commemorative D-Day Event (6 June 2024) and Celebration Event (9 June 2024).  

Refunds and arrangements will be made for all bookings.  
We apologise to all who were planning to attend.  

– Wendy Carr, Chair of the D-Day Committee.
